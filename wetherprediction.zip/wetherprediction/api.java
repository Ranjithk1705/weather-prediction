package com.example;

import java.io.*;
import java.net.*;
import org.json.*;
import java.util.*;

public class api {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the city name: ");
        String city = scan.nextLine();  // Use nextLine() to handle cities with spaces

        String apiKey = "5ed55ef76e1fd92c3b4594319eef2932"; 
        String urlString = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                JSONObject obj = new JSONObject(response.toString());
                JSONObject main = obj.getJSONObject("main");
                String weather = obj.getJSONArray("weather").getJSONObject(0).getString("description");

                System.out.println("City: " + city);
                System.out.println("Temperature: " + main.getDouble("temp") + "°C");
                System.out.println("Humidity: " + main.getInt("humidity") + "%");
                System.out.println("Condition: " + weather);
            } else {
                System.out.println("City not found or error occurred. HTTP response code: " + responseCode);
            }
        } catch (IOException e) {
            System.out.println("Network Error: " + e.getMessage());
        } catch (JSONException e) {
            System.out.println("Invalid data received. City may not exist.");
        }

        scan.close(); // Close Scanner
    }
}